"""Build and verify the four-file Sabrina Console release kit locally."""
from __future__ import annotations

import argparse
import hashlib
import os
import tempfile
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


FILES = (".env.example", "REPOSITORY.md", "skills/github-console-release/SKILL.md",
         "scripts/build_github_release.py")
ROOT = Path(__file__).resolve().parent.parent


def release_files() -> dict[str, bytes]:
    files = {}
    for name in FILES:
        path = ROOT / name
        if path.resolve() != path or not path.is_file():
            raise ValueError(f"Expected a regular release file at {name}")
        files[name] = path.read_bytes()
    settings = [line.strip() for line in files[".env.example"].decode("utf-8").splitlines()
                if line.strip() and not line.startswith("#")]
    if sorted(settings) != sorted(("EXECUTION_AUTHORIZED=false", "GEMINI_API_KEY=", "OLLAMA_MODEL=gemma3:12b")):
        raise ValueError("Template must contain the three documented placeholder settings")
    return files


def build(destination: Path) -> str:
    files = release_files()
    destination = destination.resolve()
    if destination.suffix.lower() != ".zip":
        raise ValueError("The release output must be a ZIP file")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=destination.parent, suffix=".zip", delete=False) as tmp:
        staging = Path(tmp.name)
    try:
        with ZipFile(staging, "w") as archive:
            for name, contents in files.items():
                entry = ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                entry.create_system = 3
                entry.external_attr = 0o100644 << 16
                archive.writestr(entry, contents, compress_type=ZIP_DEFLATED)
        with ZipFile(staging) as archive:
            if archive.namelist() != list(FILES) or any(archive.read(name) != data for name, data in files.items()):
                raise ValueError("Archive content verification failed")
        digest = hashlib.sha256(staging.read_bytes()).hexdigest()
        os.replace(staging, destination)
        return digest
    finally:
        staging.unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "dist/sabrina-console-release-kit.zip")
    target = parser.parse_args().output
    print(f"{build(target)}  {target}")
